import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/hooks/use-toast';
import { FavoritesTab } from '@/components/FavoritesTab';
import { NotificationsPanel } from '@/components/NotificationsPanel';
import { BadgeDisplay } from '@/components/BadgeDisplay';
import { MediaUpload } from '@/components/MediaUpload';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Star, 
  Briefcase, 
  Calendar,
  Edit2,
  LogOut,
  Upload
} from 'lucide-react';

export default function Profile() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [profile, setProfile] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    neighborhood: '',
    description: '',
    price: ''
  });

  useEffect(() => {
    if (!user) {
      navigate('/auth');
      return;
    }
    loadProfile();
  }, [user, navigate]);

  const loadProfile = async () => {
    if (!user) return;

    const { data, error } = await supabase
      .from('users')
      .select('*')
      .eq('auth_id', user.id)
      .maybeSingle();

    if (error) {
      toast({
        title: "Erro ao carregar perfil",
        description: error.message,
        variant: "destructive"
      });
    } else {
      setProfile(data);
      setFormData({
        name: data.name || '',
        phone: data.phone || '',
        neighborhood: data.neighborhood || '',
        description: data.description || '',
        price: data.price || ''
      });
    }
    setLoading(false);
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);

    const { error } = await supabase
      .from('users')
      .update(formData)
      .eq('auth_id', user.id);

    if (error) {
      toast({
        title: "Erro ao atualizar perfil",
        description: error.message,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Perfil atualizado!",
        description: "Suas informações foram atualizadas com sucesso"
      });
      setEditing(false);
      loadProfile();
    }

    setLoading(false);
  };

  const handleLogout = async () => {
    await signOut();
    navigate('/');
    toast({
      title: "Logout realizado",
      description: "Até logo!"
    });
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      </>
    );
  }

  if (!profile) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <Card className="max-w-md">
            <CardContent className="pt-6">
              <p className="text-center mb-4">Perfil não encontrado. Complete seu cadastro.</p>
              <Button onClick={() => navigate('/auth?mode=signup')} className="w-full">
                Completar Cadastro
              </Button>
            </CardContent>
          </Card>
        </div>
      </>
    );
  }

  const initials = profile.name?.split(' ').map((n: string) => n[0]).join('').toUpperCase() || 'U';

  return (
    <>
      <Header />
      <div className="min-h-screen bg-muted/30 py-8 pb-20 md:pb-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Breadcrumbs />

          {/* Profile Header */}
          <Card className="mb-6 animate-fade-in">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Avatar className="h-20 w-20">
                    <AvatarImage src={profile.avatar_url} />
                    <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
                  </Avatar>
                  <div>
                    <CardTitle className="text-2xl mb-2">{profile.name}</CardTitle>
                    <div className="space-y-2">
                      <div className="flex gap-2 flex-wrap">
                        <Badge variant="secondary">
                          {profile.type === 'worker' ? 'Prestador' : 'Contratante'}
                        </Badge>
                        {profile.plan_active && (
                          <Badge className="bg-primary/10 text-primary">Plano Pro</Badge>
                        )}
                        {profile.verified && (
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300">
                            ✓ Verificado
                          </Badge>
                        )}
                        {profile.rating_avg > 0 && (
                          <Badge variant="outline" className="gap-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            {profile.rating_avg.toFixed(1)}
                          </Badge>
                        )}
                      </div>
                      <BadgeDisplay userId={profile.id} />
                    </div>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={handleLogout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Sair
                </Button>
              </div>
            </CardHeader>
          </Card>

          <Tabs defaultValue="info" className="animate-slide-up">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="info">Info</TabsTrigger>
              <TabsTrigger value="verification">Verificação</TabsTrigger>
              <TabsTrigger value="favorites">Favoritos</TabsTrigger>
              <TabsTrigger value="notifications">Notificações</TabsTrigger>
              <TabsTrigger value="history">Histórico</TabsTrigger>
              <TabsTrigger value="stats">Stats</TabsTrigger>
            </TabsList>

            {/* Information Tab */}
            <TabsContent value="info">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>Dados Pessoais</CardTitle>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditing(!editing)}
                    >
                      <Edit2 className="h-4 w-4 mr-2" />
                      {editing ? 'Cancelar' : 'Editar'}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {editing ? (
                    <form onSubmit={handleUpdateProfile} className="space-y-4">
                      <div>
                        <Label htmlFor="name">Nome</Label>
                        <Input
                          id="name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          required
                        />
                      </div>
                      <div>
                        <Label htmlFor="phone">Telefone</Label>
                        <Input
                          id="phone"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="neighborhood">Bairro</Label>
                        <Input
                          id="neighborhood"
                          value={formData.neighborhood}
                          onChange={(e) => setFormData({ ...formData, neighborhood: e.target.value })}
                        />
                      </div>
                      {profile.type === 'worker' && (
                        <>
                          <div>
                            <Label htmlFor="description">Descrição</Label>
                            <Textarea
                              id="description"
                              value={formData.description}
                              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                              rows={4}
                            />
                          </div>
                          <div>
                            <Label htmlFor="price">Preço</Label>
                            <Input
                              id="price"
                              value={formData.price}
                              onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                              placeholder="Ex: R$ 150/dia"
                            />
                          </div>
                        </>
                      )}
                      <Button type="submit" disabled={loading}>
                        {loading ? 'Salvando...' : 'Salvar Alterações'}
                      </Button>
                    </form>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Mail className="h-5 w-5 text-muted-foreground" />
                        <span>{profile.email}</span>
                      </div>
                      {profile.phone && (
                        <div className="flex items-center gap-3">
                          <Phone className="h-5 w-5 text-muted-foreground" />
                          <span>{profile.phone}</span>
                        </div>
                      )}
                      {profile.neighborhood && (
                        <div className="flex items-center gap-3">
                          <MapPin className="h-5 w-5 text-muted-foreground" />
                          <span>{profile.neighborhood}</span>
                        </div>
                      )}
                      {profile.type === 'worker' && profile.description && (
                        <div className="pt-4 border-t">
                          <h4 className="font-semibold mb-2">Sobre</h4>
                          <p className="text-muted-foreground">{profile.description}</p>
                        </div>
                      )}
                      {profile.type === 'worker' && profile.price && (
                        <div className="flex items-center gap-3">
                          <Briefcase className="h-5 w-5 text-muted-foreground" />
                          <span className="font-semibold text-primary">{profile.price}</span>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Verification Tab */}
            <TabsContent value="verification">
              <Card>
                <CardHeader>
                  <CardTitle>Verificação de Identidade</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {profile.verified ? (
                      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                        <p className="text-green-800 font-semibold mb-2">✓ Conta Verificada</p>
                        <p className="text-sm text-green-700">
                          Sua identidade foi verificada com sucesso
                        </p>
                      </div>
                    ) : profile.verification_status === 'pending' ? (
                      <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <p className="text-yellow-800 font-semibold mb-2">⏳ Verificação Pendente</p>
                        <p className="text-sm text-yellow-700">
                          Seu documento está sendo analisado. Aguarde a aprovação.
                        </p>
                      </div>
                    ) : (
                      <>
                        <p className="text-muted-foreground mb-4">
                          Envie um documento com foto para verificar sua identidade e ganhar mais credibilidade
                        </p>
                        <MediaUpload 
                          bucket="verification-docs"
                          onUpload={async (url) => {
                            const { error } = await supabase
                              .from('users')
                              .update({ 
                                verification_document: url,
                                verification_status: 'pending'
                              })
                              .eq('auth_id', user?.id);

                            if (!error) {
                              toast({
                                title: "Documento enviado!",
                                description: "Aguarde a análise da nossa equipe"
                              });
                              loadProfile();
                            }
                          }}
                        />
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Favorites Tab */}
            <TabsContent value="favorites">
              <FavoritesTab />
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications">
              <NotificationsPanel />
            </TabsContent>

            {/* History Tab */}
            <TabsContent value="history">
              <Card>
                <CardHeader>
                  <CardTitle>Histórico de Trabalhos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8 text-muted-foreground">
                    <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>Nenhum trabalho registrado ainda</p>
                    <Button asChild className="mt-4">
                      <a href="/jobs">Buscar Trabalhos</a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Stats Tab */}
            <TabsContent value="stats">
              <div className="grid md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Trabalhos Concluídos
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{profile.jobs_done || 0}</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Avaliação Média
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-2">
                      <p className="text-3xl font-bold">
                        {profile.rating_avg > 0 ? profile.rating_avg.toFixed(1) : '-'}
                      </p>
                      {profile.rating_avg > 0 && (
                        <Star className="h-6 w-6 fill-yellow-400 text-yellow-400" />
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total de Avaliações
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{profile.rating_count || 0}</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="mt-4">
                <CardHeader>
                  <CardTitle>Status do Plano</CardTitle>
                </CardHeader>
                <CardContent>
                  {profile.plan_active ? (
                    <div className="space-y-2">
                      <Badge className="bg-green-500">Plano Pro Ativo</Badge>
                      <p className="text-sm text-muted-foreground">
                        Você tem acesso a todos os recursos premium
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <Badge variant="outline">Plano Gratuito</Badge>
                      <p className="text-sm text-muted-foreground">
                        Faça upgrade para ter maior visibilidade
                      </p>
                      <Button size="sm" className="mt-2">Assinar Plano Pro</Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
      <Footer />
    </>
  );
}
