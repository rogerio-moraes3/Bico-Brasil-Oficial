import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { FavoriteButton } from '@/components/FavoriteButton';
import { Star, MapPin, Phone, Mail, Calendar, MessageSquare, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface WorkerData {
  id: string;
  name: string;
  email: string;
  phone: string;
  city: string;
  neighborhood: string;
  category: string;
  subcategory: string;
  description: string;
  availability: string;
  price: string;
  verified: boolean;
  rating_avg: number;
  rating_count: number;
  jobs_done: number;
  created_at: string;
}

interface Rating {
  id: string;
  rating: number;
  comment: string;
  created_at: string;
  rating_user_id: string;
}

export default function WorkerProfile() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [worker, setWorker] = useState<WorkerData | null>(null);
  const [ratings, setRatings] = useState<Rating[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWorkerData();
  }, [id]);

  const loadWorkerData = async () => {
    if (!id) return;

    const { data: workerData } = await supabase
      .from('users')
      .select('*')
      .eq('id', id)
      .eq('type', 'worker')
      .eq('plan_active', true)
      .single();

    if (workerData) {
      setWorker(workerData);

      const { data: ratingsData } = await supabase
        .from('ratings')
        .select('*')
        .eq('rated_user_id', id)
        .order('created_at', { ascending: false })
        .limit(10);

      if (ratingsData) {
        setRatings(ratingsData);
      }
    }
    setLoading(false);
  };

  const handleContactWorker = async () => {
    if (!user) {
      toast({
        title: "Login necessário",
        description: "Faça login para contatar profissionais",
        variant: "destructive"
      });
      navigate('/auth');
      return;
    }

    if (!worker) return;

    // Check if conversation exists
    const { data: existingConv } = await supabase
      .from('conversations')
      .select('id')
      .eq('contractor_id', user.id)
      .eq('worker_id', worker.id)
      .single();

    if (existingConv) {
      navigate('/messages');
      return;
    }

    // Create new conversation
    const { error } = await supabase
      .from('conversations')
      .insert({
        contractor_id: user.id,
        worker_id: worker.id
      });

    if (error) {
      toast({
        title: "Erro ao iniciar conversa",
        variant: "destructive"
      });
    } else {
      navigate('/messages');
    }
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <p>Carregando...</p>
        </div>
      </>
    );
  }

  if (!worker) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <p>Profissional não encontrado</p>
        </div>
      </>
    );
  }

  const initials = worker.name?.split(' ').map(n => n[0]).join('').toUpperCase() || 'U';

  return (
    <>
      <Header />
      <div className="min-h-screen bg-muted/30 py-8 pb-20 md:pb-8">
        <div className="container mx-auto px-4 max-w-4xl">
          <Breadcrumbs />

          <Card className="mt-6">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <Avatar className="h-24 w-24 md:h-32 md:w-32">
                  <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
                </Avatar>

                <div className="flex-1">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h1 className="text-2xl md:text-3xl font-bold">{worker.name}</h1>
                        {worker.verified && (
                          <CheckCircle className="h-6 w-6 text-primary" />
                        )}
                      </div>
                      <p className="text-lg text-muted-foreground">{worker.category}</p>
                      {worker.subcategory && (
                        <p className="text-sm text-muted-foreground">{worker.subcategory}</p>
                      )}
                    </div>
                    <FavoriteButton workerId={worker.id} />
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {worker.rating_avg > 0 && (
                      <Badge variant="outline" className="gap-1">
                        <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        {worker.rating_avg.toFixed(1)} ({worker.rating_count} avaliações)
                      </Badge>
                    )}
                    <Badge variant="secondary">
                      {worker.jobs_done} trabalhos concluídos
                    </Badge>
                    {worker.price && (
                      <Badge variant="outline">{worker.price}</Badge>
                    )}
                  </div>

                  <div className="flex flex-col gap-2 text-sm text-muted-foreground mb-4">
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4" />
                      <span>{worker.neighborhood}, {worker.city}</span>
                    </div>
                    {worker.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="h-4 w-4" />
                        <span>{worker.phone}</span>
                      </div>
                    )}
                    {worker.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="h-4 w-4" />
                        <span>{worker.email}</span>
                      </div>
                    )}
                  </div>

                  <Button onClick={handleContactWorker} className="w-full md:w-auto">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Enviar Mensagem
                  </Button>
                </div>
              </div>

              {worker.description && (
                <>
                  <Separator className="my-6" />
                  <div>
                    <h3 className="font-semibold mb-2">Sobre</h3>
                    <p className="text-muted-foreground">{worker.description}</p>
                  </div>
                </>
              )}

              {worker.availability && (
                <>
                  <Separator className="my-6" />
                  <div>
                    <h3 className="font-semibold mb-2 flex items-center gap-2">
                      <Calendar className="h-4 w-4" />
                      Disponibilidade
                    </h3>
                    <p className="text-muted-foreground">{worker.availability}</p>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {ratings.length > 0 && (
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Avaliações</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {ratings.map((rating) => (
                    <div key={rating.id} className="border-b last:border-0 pb-4 last:pb-0">
                      <div className="flex items-center gap-1 mb-2">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-4 w-4 ${
                              i < rating.rating
                                ? 'fill-yellow-400 text-yellow-400'
                                : 'text-muted-foreground'
                            }`}
                          />
                        ))}
                      </div>
                      {rating.comment && (
                        <p className="text-sm text-muted-foreground mb-1">{rating.comment}</p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        {new Date(rating.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}
