import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Breadcrumbs } from "@/components/Breadcrumbs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { jobSchema } from "@/lib/validation";
import { ArrowLeft } from "lucide-react";

const PostJob = () => {
  const navigate = useNavigate();
  const { user, loading } = useAuth();
  const { toast } = useToast();
  const [isUrgent, setIsUrgent] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!loading && !user) {
      toast({
        title: "Login necessário",
        description: "Você precisa estar logado para publicar um trabalho",
        variant: "destructive"
      });
      navigate('/auth');
    }
  }, [user, loading, navigate, toast]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const data = {
      title: formData.get('title') as string,
      description: formData.get('description') as string,
      category: formData.get('category') as string,
      subcategory: formData.get('subcategory') as string || undefined,
      phone: formData.get('phone') as string,
      contractorName: formData.get('name') as string,
      neighborhood: formData.get('neighborhood') as string,
      address: formData.get('address') as string || undefined
    };

    // Validate input
    const validation = jobSchema.safeParse(data);
    if (!validation.success) {
      toast({
        title: "Erro de validação",
        description: validation.error.errors[0].message,
        variant: "destructive"
      });
      setSubmitting(false);
      return;
    }

    try {
      // Get user's profile to link as contractor
      const { data: profile } = await supabase
        .from('users')
        .select('id')
        .eq('auth_id', user?.id)
        .maybeSingle();

      const { error } = await supabase
        .from('jobs')
        .insert({
          title: validation.data.title,
          description: validation.data.description,
          category: validation.data.category,
          subcategory: validation.data.subcategory,
          contractor_name: validation.data.contractorName,
          contractor_phone: validation.data.phone,
          contractor_id: profile?.id,
          neighborhood: validation.data.neighborhood,
          address: validation.data.address,
          urgent: isUrgent,
          city: 'Presidente Prudente',
          status: 'published'
        });

      if (error) throw error;

      toast({
        title: "Trabalho publicado!",
        description: "Os profissionais da sua região poderão visualizar seu pedido em breve.",
      });
      
      setTimeout(() => navigate("/jobs"), 1500);
    } catch (error: any) {
      toast({
        title: "Erro ao publicar",
        description: "Não foi possível publicar o trabalho. Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <>
        <Header />
        <div className="min-h-screen flex items-center justify-center">
          <p>Carregando...</p>
        </div>
      </>
    );
  }

  return (
    <div className="min-h-screen flex flex-col pb-20 md:pb-0">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Breadcrumbs />
          <Button
            variant="ghost"
            onClick={() => navigate(-1)}
            className="mb-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Voltar
          </Button>
          
          <div className="mb-8">
            <h1 className="text-4xl font-bold mb-4">Publicar Trabalho</h1>
            <p className="text-lg text-muted-foreground">
              Descreva o trabalho que você precisa e receba contato de profissionais qualificados
            </p>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Detalhes do Trabalho</CardTitle>
              <CardDescription>
                Preencha os dados abaixo para publicar seu pedido
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Título do Trabalho *</Label>
                  <Input 
                    id="title"
                    name="title"
                    placeholder="Ex: Preciso de um pedreiro para construir um muro"
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria *</Label>
                    <Select name="category" required>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Construção e Reforma">Construção e Reforma</SelectItem>
                        <SelectItem value="Montagem e Manutenção">Montagem e Manutenção</SelectItem>
                        <SelectItem value="Jardinagem e Externa">Jardinagem e Externa</SelectItem>
                        <SelectItem value="Limpeza e Organização">Limpeza e Organização</SelectItem>
                        <SelectItem value="Transporte e Apoio">Transporte e Apoio</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subcategory">Subcategoria</Label>
                    <Input 
                      id="subcategory"
                      name="subcategory"
                      placeholder="Ex: Pedreiro"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrição *</Label>
                  <Textarea 
                    id="description"
                    name="description"
                    placeholder="Descreva o trabalho em detalhes..."
                    rows={4}
                    required
                  />
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="neighborhood">Bairro *</Label>
                    <Input 
                      id="neighborhood"
                      name="neighborhood"
                      placeholder="Ex: Centro"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="address">Endereço (opcional)</Label>
                    <Input 
                      id="address"
                      name="address"
                      placeholder="Rua, número"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Seu Nome *</Label>
                    <Input 
                      id="name"
                      name="name"
                      placeholder="Nome completo"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone">WhatsApp *</Label>
                    <Input 
                      id="phone"
                      name="phone"
                      type="tel"
                      placeholder="(18) 99999-9999"
                      required
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="urgent">Trabalho Urgente</Label>
                    <p className="text-sm text-muted-foreground">
                      Priorizar este pedido para profissionais disponíveis
                    </p>
                  </div>
                  <Switch 
                    id="urgent"
                    checked={isUrgent}
                    onCheckedChange={setIsUrgent}
                  />
                </div>

                <div className="flex gap-4">
                  <Button type="submit" className="flex-1" disabled={submitting}>
                    {submitting ? 'Publicando...' : 'Publicar Trabalho'}
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => navigate("/jobs")}
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>

          <div className="mt-6 p-4 bg-muted/50 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>Importante:</strong> Ao publicar, profissionais da sua região poderão 
              ver suas informações de contato e entrarão em contato via WhatsApp.
            </p>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default PostJob;
