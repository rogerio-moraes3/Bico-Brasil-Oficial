import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { FloatingActionButton } from "@/components/FloatingActionButton";
import { LazyImage } from "@/components/LazyImage";
import { PWAInstallPrompt } from "@/components/PWAInstallPrompt";
import { FAQ } from "@/components/FAQ";
import { ArrowRight, Star, Users, Clock, Shield } from "lucide-react";
import logo from "@/assets/logo.png";

const Index = () => {
  const quickActions = [
    {
      title: "Preciso de um ajudante de mudança agora",
      category: "transporte-ajuda",
      icon: "🚚",
    },
    {
      title: "Preciso de um pedreiro por um dia",
      category: "construcao-reforma",
      icon: "🧱",
    },
    {
      title: "Preciso descarregar um caminhão",
      category: "transporte-ajuda",
      icon: "📦",
    },
  ];

  const features = [
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Profissionais Verificados",
      description: "Trabalhadores avaliados pela comunidade",
    },
    {
      icon: <Clock className="h-8 w-8 text-primary" />,
      title: "Atendimento Rápido",
      description: "Encontre ajuda para trabalhos urgentes",
    },
    {
      icon: <Star className="h-8 w-8 text-primary" />,
      title: "Sistema de Avaliações",
      description: "Transparência com avaliações reais",
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Seguro e Confiável",
      description: "Plataforma verificada e segura",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col pb-20 md:pb-0">
      <Header />
      <PWAInstallPrompt />
      
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-20 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="animate-fade-in">
                <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                  Precisou de ajuda{" "}
                  <span className="text-primary">agora?</span>
                  <br />
                  Bico Brasil resolve na hora!
                </h1>
                <p className="text-xl text-muted-foreground mb-8">
                  Encontre profissionais qualificados para trabalhos manuais em 
                  sua cidade. Rápido, fácil e seguro.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Button asChild size="lg" className="text-lg">
                    <Link to="/jobs">
                      Buscar Profissionais <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="text-lg">
                    <Link to="/post-job">Publicar Trabalho</Link>
                  </Button>
                  <Button asChild variant="secondary" size="lg" className="text-lg">
                    <Link to="/auth?mode=signup">Login / Cadastre-se</Link>
                  </Button>
                </div>
              </div>
              
              <div className="flex justify-center animate-slide-up">
                <LazyImage
                  src={logo}
                  alt="Bico Brasil Mascote" 
                  className="w-full max-w-md drop-shadow-2xl"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">
              O que você precisa hoje?
            </h2>
            <div className="grid md:grid-cols-3 gap-6">
              {quickActions.map((action, index) => (
                <Card 
                  key={index} 
                  className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer border-2 hover:border-primary"
                >
                  <CardContent className="p-6">
                    <div className="text-5xl mb-4">{action.icon}</div>
                    <h3 className="font-semibold text-lg mb-2">{action.title}</h3>
                    <Button asChild variant="link" className="p-0 h-auto text-primary">
                      <Link to={`/jobs?category=${action.category}`}>
                        Ver profissionais <ArrowRight className="ml-2 h-4 w-4" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="py-16 bg-muted/30">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12 animate-fade-in">
              Por que escolher o Bico Brasil?
            </h2>
            <div className="grid md:grid-cols-4 gap-8">
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className="text-center animate-slide-up"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="flex justify-center mb-4">{feature.icon}</div>
                  <h3 className="font-semibold text-lg mb-2">{feature.title}</h3>
                  <p className="text-muted-foreground">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="py-16 bg-background">
          <div className="container mx-auto px-4">
            <FAQ />
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-20 bg-gradient-to-r from-primary to-primary/80 text-white animate-fade-in">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Pronto para começar?
            </h2>
            <p className="text-xl mb-8 text-white/90">
              Cadastre-se gratuitamente e comece a trabalhar ou encontre ajuda hoje mesmo!
            </p>
            <Button asChild size="lg" variant="secondary" className="text-lg">
              <Link to="/auth?mode=signup">
                Criar Conta Grátis <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>

      <FloatingActionButton />
      <Footer />
    </div>
  );
};

export default Index;
