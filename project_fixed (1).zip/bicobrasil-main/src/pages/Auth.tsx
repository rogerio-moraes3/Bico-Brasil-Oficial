import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { signupSchema } from '@/lib/validation';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Mail } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';

export default function Auth() {
  const [searchParams] = useSearchParams();
  const mode = searchParams.get('mode') || 'login';
  const navigate = useNavigate();
  const { signIn, signUp, user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [lgpdConsent, setLgpdConsent] = useState(false);
  const [categories, setCategories] = useState<Array<{id: string; name: string; slug: string}>>([]);
  const [selectedCity, setSelectedCity] = useState("");

  useEffect(() => {
    loadCategories();
    loadSelectedCity();
  }, []);

  // Redirect if already logged in
  useEffect(() => {
    if (user) {
      navigate('/');
    }
  }, [user, navigate]);

  const loadCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name, slug')
        .order('name');
      
      if (error) throw error;
      setCategories(data || []);
    } catch (error) {
      console.error('Error loading categories:', error);
    }
  };

  const loadSelectedCity = () => {
    const saved = localStorage.getItem('selectedCity');
    if (saved) {
      setSelectedCity(saved);
    }
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get('email') as string;
    const password = formData.get('password') as string;

    const { error } = await signIn(email, password);

    if (error) {
      toast({
        title: "Erro ao entrar",
        description: error.message === "Invalid login credentials" 
          ? "E-mail ou senha incorretos" 
          : error.message,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Bem-vindo de volta!",
        description: "Login realizado com sucesso"
      });
      navigate('/');
    }

    setLoading(false);
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/`
        }
      });

      if (error) throw error;
    } catch (error: any) {
      toast({
        title: "Erro ao entrar com Google",
        description: error.message,
        variant: "destructive"
      });
      setLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    // Verificar consentimento LGPD
    if (!lgpdConsent) {
      toast({
        title: "Consentimento Necessário",
        description: "Você precisa aceitar a Política de Privacidade e os Termos de Uso para continuar",
        variant: "destructive"
      });
      setLoading(false);
      return;
    }

    const formData = new FormData(e.currentTarget);
    const categorySlug = formData.get('category') as string;
    const selectedCat = categories.find(c => c.slug === categorySlug);

    const data = {
      name: formData.get('name') as string,
      email: formData.get('email') as string,
      password: formData.get('password') as string,
      phone: formData.get('phone') as string,
      neighborhood: formData.get('neighborhood') as string,
      type: formData.get('type') as string,
      category: selectedCat?.name || undefined,
      subcategory: formData.get('subcategory') as string || undefined,
      description: formData.get('description') as string || undefined,
      price: formData.get('price') as string || undefined,
      city_id: selectedCity || undefined
    };

    const validation = signupSchema.safeParse(data);
    
    if (!validation.success) {
      toast({
        title: "Erro de validação",
        description: validation.error.errors[0].message,
        variant: "destructive"
      });
      setLoading(false);
      return;
    }

    const { error } = await signUp(data.email, data.password, data);

    if (error) {
      toast({
        title: "Erro ao cadastrar",
        description: error.message === "User already registered" 
          ? "E-mail já cadastrado" 
          : error.message,
        variant: "destructive"
      });
    } else {
      toast({
        title: "Cadastro realizado!",
        description: "Bem-vindo ao Bico Brasil"
      });
      navigate('/');
    }

    setLoading(false);
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gradient-to-b from-background to-muted py-12 px-4 pb-20 md:pb-12">
        <div className="container max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">
                {mode === 'login' ? 'Entrar' : 'Cadastrar'}
              </CardTitle>
              <CardDescription>
                {mode === 'login' 
                  ? 'Entre com suas credenciais' 
                  : 'Crie sua conta no Bico Brasil'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {mode === 'login' ? (
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="seu@email.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha</Label>
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      placeholder="••••••"
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full" disabled={loading}>
                    {loading ? 'Entrando...' : 'Entrar'}
                  </Button>
                  
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">Ou</span>
                    </div>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={handleGoogleLogin}
                    disabled={loading}
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Entrar com Google
                  </Button>

                  <p className="text-sm text-center text-muted-foreground">
                    Não tem conta?{' '}
                    <Button
                      variant="link"
                      className="p-0"
                      onClick={() => navigate('/auth?mode=signup')}
                    >
                      Cadastre-se
                    </Button>
                  </p>
                </form>
              ) : (
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome Completo *</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">E-mail *</Label>
                    <Input id="email" name="email" type="email" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password">Senha *</Label>
                    <Input id="password" name="password" type="password" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">WhatsApp *</Label>
                    <Input id="phone" name="phone" placeholder="(18) 99999-9999" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="neighborhood">Bairro *</Label>
                    <Input id="neighborhood" name="neighborhood" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="type">Tipo de Usuário *</Label>
                    <Select name="type" required>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="contractor">Contratante</SelectItem>
                        <SelectItem value="worker">Prestador</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="category">Categoria (prestador)</Label>
                    <Select name="category">
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map(cat => (
                          <SelectItem key={cat.id} value={cat.slug}>{cat.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="description">Descrição</Label>
                    <Textarea id="description" name="description" rows={3} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="price">Preço Sugerido</Label>
                    <Input id="price" name="price" placeholder="R$ 150/dia" />
                  </div>

                  <div className="space-y-3 p-4 bg-muted rounded-lg">
                    <div className="flex items-start space-x-2">
                      <input
                        type="checkbox"
                        id="lgpd-consent"
                        checked={lgpdConsent}
                        onChange={(e) => setLgpdConsent(e.target.checked)}
                        className="mt-1"
                      />
                      <Label htmlFor="lgpd-consent" className="text-sm leading-relaxed cursor-pointer">
                        <strong>Consentimento LGPD:</strong> Autorizo o Bico Brasil a coletar, armazenar e tratar meus dados pessoais (nome, telefone, e-mail, CPF, documentos, imagens) para fins de autenticação, publicação de serviços, comunicação entre contratante e prestador, processamento de pagamentos e cumprimento de obrigações legais, conforme a Lei nº 13.709/2018 (LGPD).{' '}
                        <a href="/privacy" target="_blank" className="text-primary underline">
                          Li e aceito a Política de Privacidade
                        </a>{' '}
                        e{' '}
                        <a href="/terms" target="_blank" className="text-primary underline">
                          os Termos de Uso
                        </a>.
                      </Label>
                    </div>
                  </div>

                  <Button type="submit" className="w-full" disabled={loading || !lgpdConsent}>
                    {loading ? 'Cadastrando...' : 'Cadastrar'}
                  </Button>
                  
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <span className="w-full border-t" />
                    </div>
                    <div className="relative flex justify-center text-xs uppercase">
                      <span className="bg-background px-2 text-muted-foreground">Ou</span>
                    </div>
                  </div>

                  <Button
                    type="button"
                    variant="outline"
                    className="w-full"
                    onClick={handleGoogleLogin}
                    disabled={loading}
                  >
                    <Mail className="mr-2 h-4 w-4" />
                    Cadastrar com Google
                  </Button>

                  <p className="text-sm text-center text-muted-foreground">
                    Já tem conta?{' '}
                    <Button
                      variant="link"
                      className="p-0"
                      onClick={() => navigate('/auth?mode=login')}
                    >
                      Entre aqui
                    </Button>
                  </p>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      <Footer />
    </>
  );
}
