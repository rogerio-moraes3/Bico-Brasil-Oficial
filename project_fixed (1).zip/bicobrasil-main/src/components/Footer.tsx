import { Link } from "react-router-dom";
import logo from "@/assets/logo.png";

export const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground mt-20">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <img src={logo} alt="Bico Brasil" className="h-12 w-12" />
              <div className="flex flex-col">
                <span className="font-bold text-xl text-white">Bico Brasil</span>
                <span className="text-xs text-white/70">Presidente Prudente</span>
              </div>
            </Link>
            <p className="text-sm text-white/80 max-w-md">
              Conectamos pessoas que precisam de ajuda urgente com profissionais qualificados 
              em Presidente Prudente. Rápido, fácil e seguro.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-4">Links Úteis</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li>
                <Link to="/jobs" className="hover:text-white transition-colors">
                  Buscar Profissionais
                </Link>
              </li>
              <li>
                <Link to="/post-job" className="hover:text-white transition-colors">
                  Publicar Trabalho
                </Link>
              </li>
              <li>
                <Link to="/auth" className="hover:text-white transition-colors">
                  Entrar/Cadastrar
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-4">Redes Sociais</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li>
                <a href="https://www.instagram.com/bicobrasil_" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                  Instagram
                </a>
              </li>
              <li>
                <a href="https://www.tiktok.com/@bicobrasil" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                  TikTok
                </a>
              </li>
              <li>
                <a href="https://www.youtube.com/@BicoBrasil-l8r" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                  YouTube
                </a>
              </li>
              <li>
                <a href="https://www.linkedin.com/in/bico-brasil-1bb190397/" target="_blank" rel="noreferrer" className="hover:text-white transition-colors">
                  LinkedIn
                </a>
              </li>
              <li>
                <a href="mailto:contato.bicobrasil@gmail.com" className="hover:text-white transition-colors">
                  E-mail: contato.bicobrasil@gmail.com
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-white mb-4">Legal</h3>
            <ul className="space-y-2 text-sm text-white/80">
              <li>
                <Link to="/terms" className="hover:text-white transition-colors">
                  Termos de Uso
                </Link>
              </li>
              <li>
                <Link to="/privacy" className="hover:text-white transition-colors">
                  Política de Privacidade
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-white transition-colors">
                  Contato
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 mt-8 pt-8 text-center text-sm text-white/60">
          <p>© {new Date().getFullYear()} Bico Brasil. Todos os direitos reservados.</p>
          <p className="mt-2">Contato para LGPD: privacidade@bicobrasil.com.br</p>
        </div>
      </div>
    </footer>
  );
};
