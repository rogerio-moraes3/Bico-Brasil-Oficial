import { useEffect, useState } from 'react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { X, Download } from 'lucide-react';

export const PWAInstallPrompt = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      
      // Check if user dismissed the prompt before (localStorage)
      const dismissed = localStorage.getItem('pwa-install-dismissed');
      if (!dismissed) {
        setShowPrompt(true);
      }
    };

    window.addEventListener('beforeinstallprompt', handler);

    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches) {
      setShowPrompt(false);
    }

    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    
    if (outcome === 'accepted') {
      setShowPrompt(false);
      localStorage.removeItem('pwa-install-dismissed');
    } else {
      // User dismissed, don't show again for 7 days
      localStorage.setItem('pwa-install-dismissed', Date.now().toString());
    }
    
    setDeferredPrompt(null);
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    // Don't show again for 7 days
    localStorage.setItem('pwa-install-dismissed', Date.now().toString());
  };

  if (!showPrompt) return null;

  return (
    <Card className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:max-w-sm p-4 shadow-lg z-50 bg-primary text-primary-foreground animate-slide-up">
      <button
        onClick={handleDismiss}
        className="absolute top-2 right-2 text-primary-foreground/80 hover:text-primary-foreground transition-colors"
        aria-label="Fechar"
      >
        <X size={20} />
      </button>
      
      <div className="flex items-start gap-3">
        <Download size={24} className="mt-1 flex-shrink-0" />
        <div className="flex-1">
          <h3 className="font-semibold mb-1">📱 Instalar Bico Brasil</h3>
          <p className="text-sm text-primary-foreground/90 mb-3">
            Adicione o app à sua tela inicial para:
          </p>
          <ul className="text-sm text-primary-foreground/90 mb-3 space-y-1 list-disc list-inside">
            <li>Acesso rápido e offline</li>
            <li>Experiência como app nativo</li>
            <li>Notificações instantâneas</li>
          </ul>
          <Button 
            onClick={handleInstall}
            variant="secondary"
            size="sm"
            className="w-full font-semibold"
          >
            Instalar Agora
          </Button>
        </div>
      </div>
    </Card>
  );
};
