import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { CreditCard, Smartphone, Banknote, Loader2 } from "lucide-react";

interface PaymentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const PaymentModal = ({ open, onOpenChange }: PaymentModalProps) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [selectedMethod, setSelectedMethod] = useState<'pix' | 'credit' | 'debit' | null>(null);

  const handlePayment = async (method: 'pix' | 'credit' | 'debit') => {
    setLoading(true);
    setSelectedMethod(method);

    try {
      const { data, error } = await supabase.functions.invoke('create-mercadopago-payment', {
        body: { paymentMethod: method }
      });

      if (error) throw error;

      if (data?.init_point) {
        // Open Mercado Pago checkout in new tab
        window.open(data.init_point, '_blank');
        
        toast({
          title: "Redirecionando para pagamento",
          description: "Uma nova aba foi aberta com o Mercado Pago. Complete o pagamento lá."
        });

        onOpenChange(false);
      } else {
        throw new Error("Link de pagamento não foi gerado");
      }
    } catch (error: any) {
      toast({
        title: "Erro ao processar pagamento",
        description: "Não foi possível processar o pagamento. Tente novamente mais tarde.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
      setSelectedMethod(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Ativar Plano Pro</DialogTitle>
          <DialogDescription>
            Escolha a forma de pagamento preferida para ativar seu Plano Pro por R$ 19,90/mês
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-3 py-4">
          <Button
            variant="outline"
            className="w-full h-auto py-4 px-4 justify-start"
            onClick={() => handlePayment('pix')}
            disabled={loading}
          >
            <div className="flex items-center gap-3 w-full">
              <Smartphone className="h-6 w-6 text-primary" />
              <div className="flex-1 text-left">
                <div className="font-semibold">Pix</div>
                <div className="text-sm text-muted-foreground">
                  Pagamento instantâneo via QR Code
                </div>
              </div>
              {loading && selectedMethod === 'pix' && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
            </div>
          </Button>

          <Button
            variant="outline"
            className="w-full h-auto py-4 px-4 justify-start"
            onClick={() => handlePayment('credit')}
            disabled={loading}
          >
            <div className="flex items-center gap-3 w-full">
              <CreditCard className="h-6 w-6 text-primary" />
              <div className="flex-1 text-left">
                <div className="font-semibold">Cartão de Crédito</div>
                <div className="text-sm text-muted-foreground">
                  Renovação automática mensal
                </div>
              </div>
              {loading && selectedMethod === 'credit' && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
            </div>
          </Button>

          <Button
            variant="outline"
            className="w-full h-auto py-4 px-4 justify-start"
            onClick={() => handlePayment('debit')}
            disabled={loading}
          >
            <div className="flex items-center gap-3 w-full">
              <Banknote className="h-6 w-6 text-primary" />
              <div className="flex-1 text-left">
                <div className="font-semibold">Cartão de Débito</div>
                <div className="text-sm text-muted-foreground">
                  Pagamento único mensal
                </div>
              </div>
              {loading && selectedMethod === 'debit' && (
                <Loader2 className="h-4 w-4 animate-spin" />
              )}
            </div>
          </Button>
        </div>

        <div className="text-xs text-muted-foreground text-center pt-2">
          Pagamento processado de forma segura pelo Mercado Pago
        </div>
      </DialogContent>
    </Dialog>
  );
};