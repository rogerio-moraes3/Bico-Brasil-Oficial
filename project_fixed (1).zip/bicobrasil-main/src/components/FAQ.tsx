import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const faqItems = [
  {
    question: "Quem paga a plataforma?",
    answer: "Não cobramos comissão sobre o valor do serviço. Há um plano Pro opcional (assinatura) e anúncios regionais."
  },
  {
    question: "Como é o pagamento?",
    answer: "Contratante e prestador combinam e efetuam o pagamento diretamente (Pix, dinheiro, cartão)."
  },
  {
    question: "Como garantir confiança?",
    answer: "Verificações KYC (documento + selfie) e avaliação mútua. Recomendamos pedir referências e combinar condições por escrito."
  },
  {
    question: "E se houver problema no serviço?",
    answer: "O Bico Brasil é apenas a ponte entre as partes e não se responsabiliza pela execução. Use a avaliação pública e denuncie perfis."
  }
];

export const FAQ = () => {
  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl md:text-3xl text-center">Perguntas Frequentes</CardTitle>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible className="w-full">
          {faqItems.map((item, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left">
                {item.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground">
                {item.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </CardContent>
    </Card>
  );
};
