import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useNotifications } from '@/hooks/useNotifications';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Bell, X } from 'lucide-react';

export function NotificationPrompt() {
  const { user } = useAuth();
  const { permission, requestPermission, isSupported } = useNotifications();
  const [showPrompt, setShowPrompt] = useState(false);

  useEffect(() => {
    if (user && isSupported && permission === 'default') {
      const hasSeenPrompt = localStorage.getItem('notificationPromptSeen');
      if (!hasSeenPrompt) {
        setTimeout(() => setShowPrompt(true), 3000);
      }
    }
  }, [user, permission, isSupported]);

  const handleEnable = async () => {
    await requestPermission();
    localStorage.setItem('notificationPromptSeen', 'true');
    setShowPrompt(false);
  };

  const handleDismiss = () => {
    localStorage.setItem('notificationPromptSeen', 'true');
    setShowPrompt(false);
  };

  if (!showPrompt) return null;

  return (
    <div className="fixed bottom-20 md:bottom-4 right-4 z-50 max-w-sm animate-fade-in">
      <Card>
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <Bell className="h-5 w-5 text-primary mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold mb-1">Ativar Notificações</h3>
              <p className="text-sm text-muted-foreground mb-3">
                Receba alertas instantâneos sobre novos trabalhos e mensagens
              </p>
              <div className="flex gap-2">
                <Button onClick={handleEnable} size="sm">
                  Ativar
                </Button>
                <Button onClick={handleDismiss} variant="ghost" size="sm">
                  Agora não
                </Button>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={handleDismiss}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
