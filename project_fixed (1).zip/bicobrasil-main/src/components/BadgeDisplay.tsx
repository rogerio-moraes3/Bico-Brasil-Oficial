import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface BadgeData {
  id: string;
  name: string;
  description: string;
  icon: string;
  earned_at?: string;
}

interface BadgeDisplayProps {
  userId: string;
}

export function BadgeDisplay({ userId }: BadgeDisplayProps) {
  const [badges, setBadges] = useState<BadgeData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBadges();
  }, [userId]);

  const loadBadges = async () => {
    const { data, error } = await supabase
      .from('user_badges')
      .select(`
        earned_at,
        badges (
          id,
          name,
          description,
          icon
        )
      `)
      .eq('user_id', userId);

    if (!error && data) {
      const badgeData = data.map((item: any) => ({
        ...item.badges,
        earned_at: item.earned_at
      }));
      setBadges(badgeData);
    }
    setLoading(false);
  };

  if (loading || badges.length === 0) {
    return null;
  }

  return (
    <div className="flex flex-wrap gap-2">
      <TooltipProvider>
        {badges.map((badge) => (
          <Tooltip key={badge.id}>
            <TooltipTrigger>
              <Badge variant="secondary" className="text-lg px-3 py-1">
                {badge.icon}
              </Badge>
            </TooltipTrigger>
            <TooltipContent>
              <div className="text-center">
                <p className="font-semibold">{badge.name}</p>
                <p className="text-sm text-muted-foreground">{badge.description}</p>
                {badge.earned_at && (
                  <p className="text-xs mt-1">
                    Conquistado em {new Date(badge.earned_at).toLocaleDateString()}
                  </p>
                )}
              </div>
            </TooltipContent>
          </Tooltip>
        ))}
      </TooltipProvider>
    </div>
  );
}
