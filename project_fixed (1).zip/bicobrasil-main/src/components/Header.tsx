import { Link, useNavigate, useLocation } from "react-router-dom";
import { Button } from "./ui/button";
import { Menu, ArrowLeft } from "lucide-react";
import logo from "@/assets/logo.png";
import { ThemeToggle } from "./ThemeToggle";
import { CitySelector } from "./CitySelector";
import { PWAInstallButton } from "./PWAInstallButton";
import { useState } from "react";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "./ui/sheet";

export const Header = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [open, setOpen] = useState(false);
  const showBackButton = location.pathname !== "/" && location.pathname !== "/landing";

  const navItems = [
    { path: "/", label: "Início" },
    { path: "/jobs", label: "Buscar" },
    { path: "/post-job", label: "Cadastrar Serviço" },
    { path: "/messages", label: "Mensagens" },
    { path: "/profile", label: "Perfil" },
    { path: "/contact", label: "Suporte" },
  ];

  const handleNavClick = (path: string) => {
    navigate(path);
    setOpen(false);
  };

  return (
    <>
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-4">
            {showBackButton && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="md:hidden"
              >
                <ArrowLeft className="h-5 w-5" />
              </Button>
            )}
            
            <Link to="/" className="flex items-center gap-2">
              <img src={logo} alt="Bico Brasil" className="h-10 w-10" />
              <span className="text-xl font-bold">Bico Brasil</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className="text-sm font-medium transition-colors hover:text-primary"
              >
                {item.label}
              </Link>
            ))}
            <Button asChild size="sm" variant="default">
              <Link to="/auth?mode=login">Entrar</Link>
            </Button>
          </nav>

          <div className="flex items-center gap-2">
            <PWAInstallButton />
            <ThemeToggle />
            
            {/* Mobile Menu */}
            <Sheet open={open} onOpenChange={setOpen}>
              <SheetTrigger asChild className="md:hidden">
                <Button variant="ghost" size="icon">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right">
                <SheetHeader>
                  <SheetTitle>Menu</SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col gap-4 mt-6">
                  {navItems.map((item) => (
                    <Button
                      key={item.path}
                      variant="ghost"
                      className="justify-start"
                      onClick={() => handleNavClick(item.path)}
                    >
                      {item.label}
                    </Button>
                  ))}
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>
      <CitySelector />
    </>
  );
};
