import { useEffect, useState } from "react";
import { MapPin } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface City {
  id: string;
  name: string;
  state: string;
}

export const CitySelector = () => {
  const [cities, setCities] = useState<City[]>([]);
  const [selectedCity, setSelectedCity] = useState<string>("");

  useEffect(() => {
    loadCities();
    loadSelectedCity();
  }, []);

  const loadCities = async () => {
    const { data, error } = await supabase
      .from("cities")
      .select("id, name, state")
      .eq("active", true)
      .order("name");

    if (error) {
      console.error("Error loading cities:", error);
      return;
    }

    setCities(data || []);
  };

  const loadSelectedCity = () => {
    const saved = localStorage.getItem("selectedCity");
    if (saved) {
      setSelectedCity(saved);
    }
  };

  const handleCityChange = (cityId: string) => {
    setSelectedCity(cityId);
    localStorage.setItem("selectedCity", cityId);
    window.dispatchEvent(new CustomEvent("cityChanged", { detail: cityId }));
  };

  return (
    <div className="w-full bg-muted/50 border-b">
      <div className="container mx-auto px-4 py-2">
        <div className="flex items-center gap-2 max-w-xs">
          <MapPin className="h-4 w-4 text-primary" />
          <Select value={selectedCity} onValueChange={handleCityChange}>
            <SelectTrigger className="h-9 bg-background">
              <SelectValue placeholder="Selecione sua cidade" />
            </SelectTrigger>
            <SelectContent>
              {cities.map((city) => (
                <SelectItem key={city.id} value={city.id}>
                  {city.name} - {city.state}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};
