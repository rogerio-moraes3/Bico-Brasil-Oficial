import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  signUp: (email: string, password: string, userData: any) => Promise<{ error: any }>;
  signIn: (email: string, password: string) => Promise<{ error: any }>;
  signOut: () => Promise<void>;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    // Set up auth state listener FIRST (prevents missing auth events)
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      console.log('Auth state changed:', event, session?.user?.id);
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);

      // Handle profile creation with setTimeout to avoid deadlock
      if (event === 'SIGNED_IN' && session?.user) {
        setTimeout(async () => {
          try {
            const { data: existingProfile } = await supabase
              .from('users')
              .select('id')
              .eq('auth_id', session.user.id)
              .maybeSingle();

            if (!existingProfile) {
              const fullName = session.user.user_metadata.full_name || 
                             session.user.user_metadata.name || '';
              const email = session.user.email || '';
              
              // Get first active city as default
              const { data: cities } = await supabase
                .from('cities')
                .select('id')
                .eq('active', true)
                .order('name')
                .limit(1);
              
              await supabase
                .from('users')
                .insert({
                  auth_id: session.user.id,
                  email: email,
                  name: fullName,
                  phone: '',
                  city_id: cities?.[0]?.id || null,
                  neighborhood: '',
                  type: 'contractor',
                  category: null,
                  subcategory: null,
                  description: null,
                  price: null
                });
            }
          } catch (error) {
            console.error('Error creating profile:', error);
          }
        }, 0);
      }
    });

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, userData: any) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            ...userData,
            full_name: userData.name
          }
        }
      });

      if (error) throw error;

      // Create user profile
      if (data.user) {
        const { error: profileError } = await supabase
          .from('users')
          .insert({
            auth_id: data.user.id,
            email: email,
            name: userData.name,
            phone: userData.phone,
            city_id: userData.city_id,
            neighborhood: userData.neighborhood,
            type: userData.type,
            category: userData.category,
            subcategory: userData.subcategory,
            description: userData.description,
            price: userData.price
          });

        if (profileError) throw profileError;
      }

      return { error: null };
    } catch (error: any) {
      return { error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;
      return { error: null };
    } catch (error: any) {
      return { error };
    }
  };

  const signOut = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: "Você saiu",
        description: "Até logo!"
      });
    } catch (error: any) {
      toast({
        title: "Erro ao sair",
        description: "Não foi possível sair. Tente novamente.",
        variant: "destructive"
      });
    }
  };

  return (
    <AuthContext.Provider value={{ user, session, signUp, signIn, signOut, loading }}>
      {children}
    </AuthContext.Provider>
  );
};
