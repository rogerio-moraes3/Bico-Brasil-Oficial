import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    const body = await req.json();
    console.log("Webhook received:", { type: body.type, id: body.data?.id });

    // Verify webhook signature from Mercado Pago
    const webhookSecret = Deno.env.get("MERCADOPAGO_WEBHOOK_SECRET");
    
    if (!webhookSecret) {
      console.error("MERCADOPAGO_WEBHOOK_SECRET not configured");
      return new Response(
        JSON.stringify({ error: "Server configuration error" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 500,
        }
      );
    }

    const xSignature = req.headers.get("x-signature");
    const xRequestId = req.headers.get("x-request-id");

    if (!xSignature || !xRequestId) {
      console.error("Missing signature headers");
      return new Response(
        JSON.stringify({ error: "Unauthorized" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    // Parse signature components
    const parts = xSignature.split(",");
    let ts, hash;
    for (const part of parts) {
      const [key, value] = part.split("=");
      if (key && value) {
        if (key.trim() === "ts") ts = value;
        if (key.trim() === "v1") hash = value;
      }
    }

    if (!ts || !hash) {
      console.error("Invalid signature format");
      return new Response(
        JSON.stringify({ error: "Invalid signature" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 401,
        }
      );
    }

    // Verify signature using Web Crypto API
    const manifest = `id:${body.data.id};request-id:${xRequestId};ts:${ts};`;
    const encoder = new TextEncoder();
    const keyData = encoder.encode(webhookSecret);
    const messageData = encoder.encode(manifest);
    
    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      keyData,
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    
    const signature = await crypto.subtle.sign("HMAC", cryptoKey, messageData);
    const hashArray = Array.from(new Uint8Array(signature));
    const calculatedHash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    if (calculatedHash !== hash) {
      console.error("Invalid webhook signature");
      return new Response(
        JSON.stringify({ error: "Forbidden" }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 403,
        }
      );
    }

    // Mercado Pago sends notifications about payment updates
    if (body.type === "payment") {
      const paymentId = body.data.id;
      const accessToken = Deno.env.get("MERCADOPAGO_ACCESS_TOKEN");

      // Get payment details from Mercado Pago
      const mpResponse = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: {
          "Authorization": `Bearer ${accessToken}`
        }
      });

      const paymentData = await mpResponse.json();
      console.log("Payment data from MP:", { id: paymentData.id, status: paymentData.status });

      const externalReference = paymentData.external_reference; // Our payment.id
      const status = paymentData.status;

      // Validate external reference
      if (!externalReference || typeof externalReference !== 'string') {
        console.error("Invalid external reference");
        return new Response(
          JSON.stringify({ error: "Invalid payment reference" }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 400,
          }
        );
      }

      // Verify payment exists before processing
      const { data: existingPayment } = await supabaseClient
        .from('payments')
        .select('id, status, amount, user_id')
        .eq('id', externalReference)
        .single();

      if (!existingPayment) {
        console.error("Payment not found:", externalReference);
        return new Response(
          JSON.stringify({ error: "Payment not found" }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 404,
          }
        );
      }

      // Prevent replay attacks - only process pending payments
      if (existingPayment.status !== 'pending') {
        console.log("Payment already processed:", externalReference);
        return new Response(
          JSON.stringify({ received: true, message: "Payment already processed" }),
          {
            headers: { ...corsHeaders, "Content-Type": "application/json" },
            status: 200,
          }
        );
      }

      // Update our payment record
      if (status === "approved") {
        // Payment was approved
        const { error: updateError } = await supabaseClient
          .from('payments')
          .update({
            status: 'paid',
            webhook_response: paymentData,
            subscription_start: new Date().toISOString(),
            subscription_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString() // 30 days
          })
          .eq('id', externalReference);

        if (updateError) {
          console.error("Error updating payment:", updateError);
          throw updateError;
        }

        // Activate user's plan
        const { data: payment } = await supabaseClient
          .from('payments')
          .select('user_id')
          .eq('id', externalReference)
          .single();

        if (payment) {
          const { error: userError } = await supabaseClient
            .from('users')
            .update({ plan_active: true })
            .eq('id', payment.user_id);

          if (userError) {
            console.error("Error activating plan:", userError);
          } else {
            console.log("Plan activated for user:", payment.user_id);
          }
        }
      } else if (status === "rejected" || status === "cancelled") {
        // Payment failed
        await supabaseClient
          .from('payments')
          .update({
            status: 'failed',
            webhook_response: paymentData
          })
          .eq('id', externalReference);
      }
    }

    return new Response(
      JSON.stringify({ received: true }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error: any) {
    console.error("Error in mercadopago-webhook:", error);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});