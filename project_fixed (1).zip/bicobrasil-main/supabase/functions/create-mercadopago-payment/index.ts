import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

interface PaymentRequest {
  paymentMethod: 'pix' | 'credit' | 'debit';
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? ""
    );

    // Authenticate user
    const authHeader = req.headers.get("Authorization")!;
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(token);

    if (authError || !user) {
      throw new Error("Usuário não autenticado");
    }

    // Get user profile
    const { data: profile, error: profileError } = await supabaseClient
      .from('users')
      .select('id, email, name, phone')
      .eq('auth_id', user.id)
      .maybeSingle();

    if (profileError || !profile) {
      throw new Error("Perfil de usuário não encontrado");
    }

    // Check rate limiting - verify no pending payment in last hour
    const { data: canCreate } = await supabaseClient
      .rpc('can_create_payment', { _user_id: profile.id });

    if (!canCreate) {
      console.log("Rate limit: User has pending payment", profile.id);
      return new Response(
        JSON.stringify({ error: "Você já tem um pagamento pendente. Aguarde antes de criar outro." }),
        {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
          status: 429,
        }
      );
    }

    const { paymentMethod } = await req.json() as PaymentRequest;

    // Create payment record
    const { data: payment, error: paymentError } = await supabaseClient
      .from('payments')
      .insert({
        user_id: profile.id,
        amount: 19.90,
        gateway: 'mercadopago',
        status: 'pending'
      })
      .select()
      .single();

    if (paymentError) throw paymentError;

    const accessToken = Deno.env.get("MERCADOPAGO_ACCESS_TOKEN");
    if (!accessToken) {
      throw new Error("Token do Mercado Pago não configurado");
    }

    // Create preference for Mercado Pago
    const preference = {
      items: [
        {
          id: payment.id,
          title: "Plano Pro - Bico Brasil",
          description: "Assinatura mensal do Plano Pro para maior visibilidade",
          quantity: 1,
          unit_price: 19.90,
          currency_id: "BRL"
        }
      ],
      payer: {
        name: profile.name,
        email: profile.email || `${profile.phone}@bicobrasil.temp`,
        phone: {
          number: profile.phone
        }
      },
      payment_methods: {
        excluded_payment_types: [],
        installments: paymentMethod === 'credit' ? 1 : undefined
      },
      back_urls: {
        success: `${req.headers.get("origin")}/payment-success`,
        failure: `${req.headers.get("origin")}/payment-failed`,
        pending: `${req.headers.get("origin")}/payment-pending`
      },
      auto_return: "approved",
      notification_url: `${Deno.env.get("SUPABASE_URL")}/functions/v1/mercadopago-webhook`,
      external_reference: payment.id,
      statement_descriptor: "BICO BRASIL"
    };

    // Set payment method restrictions
    if (paymentMethod === 'pix') {
      (preference.payment_methods as any).excluded_payment_types = [
        { id: "credit_card" },
        { id: "debit_card" },
        { id: "ticket" }
      ];
    } else if (paymentMethod === 'debit') {
      (preference.payment_methods as any).excluded_payment_types = [
        { id: "credit_card" },
        { id: "ticket" }
      ];
    } else if (paymentMethod === 'credit') {
      (preference.payment_methods as any).excluded_payment_types = [
        { id: "debit_card" },
        { id: "ticket" }
      ];
    }

    console.log("Creating Mercado Pago preference:", JSON.stringify(preference));

    const mpResponse = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${accessToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(preference)
    });

    const mpData = await mpResponse.json();

    if (!mpResponse.ok) {
      console.error("Mercado Pago error:", mpData);
      throw new Error(`Erro no Mercado Pago: ${mpData.message || 'Erro desconhecido'}`);
    }

    console.log("Mercado Pago preference created:", mpData.id);

    return new Response(
      JSON.stringify({
        init_point: mpData.init_point,
        payment_id: payment.id,
        preference_id: mpData.id
      }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      }
    );
  } catch (error: any) {
    console.error("Error in create-mercadopago-payment:", error);
    return new Response(
      JSON.stringify({ error: "Failed to create payment" }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      }
    );
  }
});